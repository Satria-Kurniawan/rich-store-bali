

<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="overflow-x-auto relative w-full my-5">
        <table class="w-full table-auto bg-white rounded-xl overflow-hidden border-collapse border">
            <thead>
                <tr class="bg-slate-800 text-white">
                    <th class="py-2 px-6">Gambar</th>
                    <th class="py-2 px-6">Produk</th>
                    <th class="py-2 px-6">Jumlah</th>
                    <th class="py-2 px-6">Total Harga</th>
                    <th class="py-2 px-6">Tanggal</th>
                    <th class="py-2 px-6">Admin</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b text-center">
                        <td class="py-2 px-6 flex justify-center">
                            <img src="<?php echo e(asset('photos/' . $item->product->photo)); ?>" alt="Photo" class="w-10 h-10">
                        </td>
                        <td class="py-2 px-6"><?php echo e($item->product->name); ?></td>
                        <td class="py-2 px-6"><?php echo e($item->product_quantity); ?></td>
                        <td class="py-2 px-6"><?php echo e($item->price_total); ?></td>
                        
                        <td class="py-2 px-6"><?php echo e($item->created_at->isoFormat('dddd, D MMMM Y')); ?></td>
                        <td class="py-2 px-6"><?php echo e($item->user->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Freelance\rich-store\resources\views/admin/transaction.blade.php ENDPATH**/ ?>