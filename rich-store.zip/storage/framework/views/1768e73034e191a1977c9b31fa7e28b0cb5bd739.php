

<?php $__env->startSection('title', 'Pembukuan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-4 gap-6">
        
        <div class="col-span-3">
            <div class="grid grid-cols-4 gap-2 my-5">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="/admin/product-add-to-cart/product-<?php echo e($item->id); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="bg-white rounded-xl p-3 md:max-w-xs">
                            <img src="<?php echo e(asset('photos/' . $item->photo)); ?>" alt="Photo" class="w-full md:h-40">
                            <span><?php echo e($item->name); ?></span>
                        </div>
                        <button type="submit">Add to Cart</button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        

        
        <div class="col-span-1 md:-mr-5">
            <div class="bg-white p-5 h-screen">
                <div class="grid grid-cols-10 gap-2">
                    <?php $__currentLoopData = $cartContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-span-4"><?php echo e($item->product->name); ?></div>
                        <div class="col-span-3 flex justify-center items-center">
                            <form action="/admin/product-cart/item-reduction-<?php echo e($item->id); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <button type="submit">
                                    <i class="fa-solid fa-square-minus text-xl"></i>
                                </button>
                            </form>
                            <div class="mx-2">
                                <?php echo e($item->product_quantity); ?>

                            </div>
                            <form action="/admin/product-cart/item-addition-<?php echo e($item->id); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <button type="submit">
                                    <i class="fa-solid fa-square-plus text-xl"></i>
                                </button>
                            </form>
                        </div>
                        <div class="col-span-3"><?php echo e($item->price_total); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-span-7 mt-3">
                        Total Harga:
                    </div>
                    <div class="col-span-3 mt-3">
                        <?php echo e($cartContents->sum('price_total')); ?>

                    </div>
                    
                    <div class="col-span-10 mt-3">
                        <form action="/admin/record-transaction" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full bg-green-500 py-1.5 px-3 rounded-md text-white font-semibold uppercase">
                                Catat Transaksi
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Freelance\rich-store\resources\views/admin/pembukuan.blade.php ENDPATH**/ ?>