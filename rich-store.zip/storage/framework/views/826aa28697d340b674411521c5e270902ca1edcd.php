

<?php $__env->startSection('title', 'Category List'); ?>

<?php $__env->startSection('content'); ?>
    <a href="/admin/category-add" class="flex justify-end">
        <button class="bg-green-500 py-1.5 px-3 rounded-md text-white font-semibold uppercase mt-5">Tambah</button>
    </a>
    <div class="overflow-x-auto relative w-full mt-2">
        <table class="w-full table-auto bg-white rounded-xl overflow-hidden border-collapse border">
            <thead>
                <tr class="bg-slate-800 text-white">
                    <th class="py-2 px-6">Kategori</th>
                    <th class="py-2 px-6">Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b text-center">
                        <td class="py-2 px-6"><?php echo e($item->name); ?></td>
                        <td>
                            <a href="/admin/category-edit/<?php echo e($item->id); ?>">
                                <i class="fa-solid fa-pen-to-square text-2xl text-blue-500 mr-1"></i>
                            </a>
                            <a href="/admin/category-del/<?php echo e($item->id); ?>">
                                <i class="fa-solid fa-trash-can text-2xl text-red-500 ml-1"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Freelance\rich-store\resources\views/admin/categories/category-list.blade.php ENDPATH**/ ?>